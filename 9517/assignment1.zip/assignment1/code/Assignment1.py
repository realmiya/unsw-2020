# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 23:05:46 2020
@author: z5323011 xiaoyu dong
"""
#......IMPORT .........
import argparse
import numpy as np
import cv2
import matplotlib.pyplot as plt
from matplotlib.pyplot import plot,savefig
from numpy import *
import copy



def task1(OR):
    # high= dimension[0]=800
    #width = dimension[1]=600
    t = 60
    tNew = 50
    iteration=0
    tNewListy = []
    IterationTimex = []
    while abs(tNew-t)>=0.01:
        iteration=iteration+1
        # for i in range(width):
        #     for j in range(high):
        #         if OR[i, j] >= tNew:
        #             Over = OR[i, j]
        #             listOvert.append(Over)
        #         else:
        #             Under = OR[i, j]
        #             listUndert.append(Under)
        # two for make my computer broken but it works!but need to wait for 20 minutes
        mu1 = np.mean(OR[OR>=tNew])
        mu0 = np.mean(OR[OR<tNew])
        t=tNew
        tNew = (mu1 + mu0)/2
        tNewListy.append(tNew)
        IterationTimex.append(iteration)

    for i in range(high):
        for j in range(width):
            if OR[i, j] >= tNew:
                OR[i, j]=0
                #let white rice be balck，black become white
            else:
                OR[i, j]=255
    # cv2.imwrite("binary imagetask1.jpg", OR)
    printt=round(tNew,1)
    titleSTR="Threshold Value="+str(printt)
    plt.title(titleSTR)
    plt.imshow(OR, "gray")
    plt.savefig(InputFilename+"_Task1"+".png")
    plt.cla()
    plt.plot(IterationTimex, tNewListy,label='t value',linewidth=1)
    plt.title('plot of threshold value t at every iteration', fontsize=14)
    plt.grid()
    plt.xlabel('iteration time',fontsize=14)
    plt.ylabel('threshold value t',fontsize=14)
    plt.legend()
    plt.savefig(f'{InputFilename}plot_Iteration_Times.png')
    return OR


def smartneighbour(LabelMatrix,i,j):
    listN=[LabelMatrix[i-1,j-1],LabelMatrix[i-1,j],LabelMatrix[i-1,j+1],LabelMatrix[i, j - 1],LabelMatrix[i, j + 1],LabelMatrix[i + 1, j - 1],LabelMatrix[i + 1, j],LabelMatrix[i + 1, j + 1]]
    return listN

def medianBlur(task1Out):
    task2img = copy.deepcopy(task1Out)
    # hand write remove noise
    for i in range(high):
        for j in range(width):
            # width0-799
            # high 0-599
            # neighbour
            if i == 0 and j == 0:
                list3neighbours = [task2img[1, 0], task2img[1, 1], task2img[0, 1], task2img[i, j]]
                replace00 = np.median(list3neighbours)
                task2img[i, j] = replace00

            elif j == 0 and i == high - 1:
                list3neighbours0 = [task2img[high - 1, 1], task2img[high - 2, 1], task2img[high - 2, 0], task2img[i, j]]
                replace000 = np.median(list3neighbours0)
                task2img[i, j] = replace000

            elif j == width - 1 and i == high - 1:
                list3neighboursBIG = [task2img[high - 1, width - 2], task2img[high - 2, width - 2],
                                      task2img[high - 2, width - 1], task2img[i, j]]
                replaceBIG = np.median(list3neighboursBIG)
                task2img[i, j] = replaceBIG

            elif j == width - 1 and i == 0:
                list3neighboursShort = [task2img[0, width - 2], task2img[1, width - 2], task2img[1, width - 1],
                                        task2img[i, j]]
                replaceShort = np.median(list3neighboursShort)
                task2img[i, j] = replaceShort

            elif j != 0 and j != width - 1 and i == 0:
                list5neighbours = [task2img[0, j - 1], task2img[1, j - 1], task2img[1, j], task2img[1, j + 1],
                                   task2img[0, j + 1], task2img[i, j]]
                replace5 = np.median(list5neighbours)
                task2img[i, j] = replace5

            elif j == 0 and i != 0 and i != high - 1:
                list5neighbours1 = [task2img[i - 1, 0], task2img[i - 1, 1], task2img[i, 1], task2img[i + 1, 1],
                                    task2img[i + 1, 0], task2img[i, j]]
                replace51 = np.median(list5neighbours1)
                task2img[i, j] = replace51

            elif j == width - 1 and i != 0 and i != high - 1:
                list5neighbours2 = [task2img[i - 1, j], task2img[i - 1, j - 1], task2img[i, j - 1],
                                    task2img[i + 1, j - 1], task2img[i + 1, j], task2img[i, j]]
                replace51 = np.median(list5neighbours2)
                task2img[i, j] = replace51
            elif i == high - 1 and j != 0 and j != width - 1:
                list5neighbours3 = [task2img[high - 1, j - 1], task2img[i - 1, j - 1], task2img[i - 1, j],
                                    task2img[i - 1, j + 1], task2img[high - 1, j + 1], task2img[i, j]]
                replace5 = np.median(list5neighbours3)
                task2img[i, j] = replace5
            else:
                list8neighbours = [task2img[i - 1, j - 1], task2img[i - 1, j], task2img[i - 1, j + 1],
                                   task2img[i, j + 1], task2img[i, j - 1], task2img[i + 1, j + 1], task2img[i + 1, j],
                                   task2img[i + 1, j - 1], task2img[i, j]]
                replace8 = np.median(list8neighbours)
                task2img[i, j] = replace8

    return task2img


def task2(task1Out):
    task2img = medianBlur(task1Out)
    task2img = medianBlur(task2img)
    task2img = medianBlur(task2img)

#############################################################
    imgT2enlarge=cv2.copyMakeBorder(task2img,1,1,1,1,cv2.BORDER_CONSTANT,value = 255)
    #print(imgT2enlarge.shape)
    #when value is 255, it is backround(white)

#first pass:
    LabelMatrix = np.zeros([high+2, width+2], dtype=np.int)
    #print(LabelMatrix.shape)
    #print(high)
    # #use 0 as the element of the matrix
    LabelNum=1
    labelList = []
    BigLabelDict={}
    for i in range(1,high+1):
        for j in range(1,width+1):
            if imgT2enlarge[i,j]==0:#when imgT2enlarge[i,j]==0 If the pixel is not the background:,i.e it is a black rice! then
                labelFlag=smartneighbour(LabelMatrix,i,j)
                #print(labelFlag)
                for item in labelFlag:
                    if item != 0:#here to judge whether the flag has been labelled, if !=0 means it has a flag already, so append
                        labelList.append(item)
                if len(labelList)==0:
                    #if it has not been labelled，it is a rice and it has never been labeled,
                    # so now need to label this point part of rice
                    LabelMatrix[i,j]=LabelNum
                    LabelNum=LabelNum+1#labe starts from 1

                else:
                    #it has been labeled before:we need the min labelNum of its neiboughours
                    LabelMatrix[i,j]=np.min(labelList)
                    if np.min(labelList) not in BigLabelDict:#if the min label in the label list is not in the LabelDCICT
                        BigLabelDict[np.min(labelList)]=[]    # we need to open a empty list as the value for the key
                        for num in labelList:
                            BigLabelDict[np.min(labelList)].append(num)
                    else:#if the label has been in the BigLabelDict as a key, we need to add all label of the same labellist into the value of the key
                        for num in labelList:
                            BigLabelDict[np.min(labelList)].append(num)
                    labelList.clear()
    #plt.matshow(LabelMatrix)
    # plt.cla()
    # plt.title("1pass")
    # plt.imshow(LabelMatrix)
    # plt.show()
        #print(BigLabelDict)
  #同一个label list里面所有label都属于同一个key，这个key就是最小的那个label数字
    #print(len(BigLabelDict))

    #second pass
    for i in BigLabelDict:
        BigLabelDict[i] = set(BigLabelDict[i])
   #print(d)
    #print(BigLabelDict)
    #count(BigLabelDict)
    count={}
    listU = []
    for i in BigLabelDict.values():
        listU.append(i)
    #print(list)
    lis = map(set, listU)
    unions = []
    for item in lis:
        temp = []
        for s in unions:
            if not s.isdisjoint(item):
                item = s.union(item)
            else:
                temp.append(s)
        temp.append(item)
        unions = temp
    #print(unions)
    finalDict={}
    KeyList=[]
    for uset in unions:
        listeach=list(uset)
        lowestlab=(np.min(listeach))
        KeyList.append(lowestlab)# from stackover:https://stackoverflow.com/questions/20154368/union-find-implementation-using-python

    #print(KeyList)
    for uset in unions:
        for key in KeyList:
            if key in uset:
                finalDict[key] =uset
    #print(finalDict)


    for y in range(high + 2):
        for x in range(width + 2):
            if imgT2enlarge[y, x] == 0:  #if the pixel is not in the background(ie it is foreground)
                for final in finalDict:
                    if LabelMatrix[y,x] in finalDict[final]:
                        LabelMatrix[y, x] = final#if the label of the label matrix is in the value of certain final dictionary'key, select the key as the new final label.
                    #in this way, we can confirm the label in the label matrix of one rice kernel can be the same.
                    #then we start to count the number of the keys in
                    """find the neighbour with the smallest label and assign the same label to the current pixel
                           Store the equivalence between neighbouring labels"""
                if LabelMatrix[y, x] in count:
                    count[LabelMatrix[y, x]] += 1
                else:
                    count[LabelMatrix[y, x]] = 1
                    # I also used this dictionary method to count the amount in my lab 1
                    # to count the number of different pixel value  plot the Histogram bar chart
    # print(f"NUMber of total good rice and bad rice :{len(finalDict)}")
    #print(f"label of count structure:{count}")
    NUMofObject=len(count)   #len(finalDict)=len(count)  =NUMofObject= NUMber of total good rice and bad rice
    #print(f"NUMber of total good rice and bad rice :{NUMofObject}")
    plt.cla()
    plt.title(f"filtered binary image \n number of rice kernels:{NUMofObject}")
    plt.imshow(task2img, "gray")
    plt.savefig(f"{InputFilename}_Task2.png")
    
    return LabelMatrix
# as there are still some noise in the processed img after my medium blur, I have to set min area>10 or use the medium i wrote to filter twice to get the exactly correct number of rice kernel





def task3(LabelMatrix,min_area):
    """Task 3: Percentage of damaged rice kernels (2 marks)
Damaged rice kernels occupy a smaller area in comparison to the whole kernels. Given a minimum pixel area ‘min_area’, using the connected component labels generated in Task 2, find the number of damaged kernels (components occupying a pixel area < min_area ) and the number of whole kernels (components occupying a pixel area > = min_area ). Divide the number of damaged kernels by the total number of rice kernels in the image to get the percentage of damaged rice kernels.
● Input: connected components labelled from Task 2, threshold value ‘min_area’ (choose an appropriate value which can separate the damaged kernels from the whole ones)
● Output: percentage of damaged rice kernels, binary image excluding all the damaged kernels"""
    count3={}
    for y in range(high + 2):
        for x in range(width + 2):
            if LabelMatrix[y, x] != 0:  # if has been labelled
                if LabelMatrix[y, x] in count3:
                    count3[LabelMatrix[y, x]] += 1
                else:
                    count3[LabelMatrix[y, x]] = 1
    NUMofObject=len(count3)
    NumOfRiceL=[]
    NumofDamagedKernelL=[]
    for label in count3:
        if count3[label]>=min_area:
            NumOfRiceL.append(label)
        else:
            NumofDamagedKernelL.append(label)
    percentage=round((100*len(NumofDamagedKernelL)/NUMofObject),3)
    task3img=copy.deepcopy(LabelMatrix)
    h,w=task3img.shape
    #print(h)
    for hy in range(h):
        for wx in range(w):
            if task3img[hy,wx]==0:
                task3img[hy,wx]=255
            elif task3img[hy,wx] in NumOfRiceL:
                task3img[hy,wx]=0
            elif task3img[hy,wx] in NumofDamagedKernelL:
                task3img[hy,wx]=255
    task3img=task3img[1:-1,1:-1]
    plt.title(f"After Removing_Damaged_kernel \n percentage of damaged rice kernels: {percentage}%")
    plt.imshow(task3img, "gray")
    plt.savefig(f"{InputFilename}_Task3.png")
    print(f"Number of total good rice and bad rice :{NUMofObject}")
    print(f"Number of damaged kernel :{len(NumofDamagedKernelL)}")
    print(f"Number of good rice kernel :{len(NumOfRiceL)}")
    print(f"percentage of damaged rice kernels :{percentage}%")
    return percentage,task3img




    
my_parser = argparse.ArgumentParser()
my_parser.add_argument('-o','--OP_folder', type=str,help='Output folder name', default = 'C:/Users/Administrator/9517/A1')
#生成图像存在这个目录
my_parser.add_argument('-m','--min_area', type=int,action='store', required = True, help='Minimum pixel area to be occupied, to be considered a whole rice kernel')
my_parser.add_argument('-f','--input_filename', type=str,action='store', required = True, help='Filename of image ')
# Execute parse_args()

args = my_parser.parse_args()
if __name__ == "__main__":
    InputFilename=args.input_filename
    min_area=args.min_area
    Or = cv2.imread(InputFilename, cv2.IMREAD_GRAYSCALE)
    OR = copy.deepcopy(Or)
    dimension = OR.shape
    high = dimension[0]
    width = dimension[1]
    OutputBinaryImage = task1(OR)
    task2Out= task2(OutputBinaryImage)
    task3 = task3(task2Out,min_area)



